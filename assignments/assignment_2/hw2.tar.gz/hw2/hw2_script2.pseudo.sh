#!/bin/bash

# Part 1: create template file using "gly606_hw2/ufs-land.namelist.US-SRG"
# Example script: https://github.com/act-hydro/GLY606_2024/blob/main/in_class_practice/bash_practice/1.create_config_template.sh

# Following site specific information needs to be replaced using unique place holders:
#	1) US-SRG - site_id
# 	2) 2009-12-31 - date for initial condition (please note that all model runs in our study starts from <start_year>-01-01
#	                so we only need to replace the year, which is (start_year-1))
#	3) 2010-01-01 - simulation start date (all model runs starts from <start_year>-01-01
#	                so we only need to replace the year, which is start_year
#	4) 365 - # of run days, here we only have forcings for 5 days, so this number needs to be replaced

# Define the name of template files
<insert code here>

# Following line: 1) replace "US-SRG" using "REGION" and 2) create new template file (use `sed`)
<insert code here>

# The option "-i" means direct modification to the file
<insert code here>

# Part 2: generate configuration files for multiple sites 
# Example script: https://github.com/act-hydro/GLY606_2024/blob/main/in_class_practice/bash_practice/2.generate_config_for_multiple_site.sh

# We will need to replace the unique place holders using site specific information
#	1) site_id; 2) year for init condition; 3) start year; 4) # of run days 

for line in `cat gly606_hw2/site_list.txt`; do
        # Step 1: extract site_id and model run year
        #         from "gly606_hw2/site_list.txt" file
        # Example script: https://github.com/act-hydro/GLY606_2024/blob/main/in_class_practice/bash_practice/for_loop.sh

	<insert code here>

	# Step 2: Define the name of configuration files for each site
	<insert code here>

	# Step 3: Use `sed` to replace the unique places holders with site specific information
	# Note: the # of run days is 5 in our test case (run_days=5)
	run_days=5
	<insert code here>

done




