#!/bin/bash

for line in `cat gly606_hw2/site_list.txt`; do
	# Step 1: extract site_id and model run year
	#         from "gly606_hw2/site_list.txt" file
	# Example script: https://github.com/act-hydro/GLY606_2024/blob/main/in_class_practice/bash_practice/for_loop.sh

	<insert code here>

	# Step 2: make directory (mkdir) for each site

	<insert code here>
	
	# Step 3: within each site directory, make sub-directory
	#         to store initial condition, forcing, and static file

	<insert code here>
	
	# Step 4: copy files (cp) from "gly606_hw2" to each subdir
	# Syntax for "cp" can be referred to 
	# https://github.com/act-hydro/GLY606_2024/blob/main/in_class_practice/bash_practice/common_bash_comments.pdf

	# for example, if we want to copy ameriflux_static_fields.C1152.CA-Cbo.nc in "gly606_hw2" folder 
	#	to "model_run/CA-Cbo/static" folder
	#	we would use "cp gly606_hw2/ameriflux_static_fields.C1152.CA-Cbo.nc model_run/CA-Cbo/static"

	# 4.1. copy the static file 

	<insert code here>

	# 4.2. copy the initial condition file
	# note that given model run starts from <start_year>-01-01
	# the date for initial condition file should be previous year
	year_pre=$((start_year - 1))
	<insert code here>

	# 4.3. copy the meteorological forcing file
	# use for-loop to loop through 5 days

	<insert code here>

done
